package com.kyzer.remittance.service;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kyzer.remittance.model.TransactionData;
import com.kyzer.remittance.repository.TransactionRepository;

@Service
public class TransactionService {

	@Autowired
	TransactionRepository repository;

	public List<TransactionData> sortEntries() {
		List<TransactionData> sortedEntries = repository.findAllByOrderByCollectionIDAsc();

		List<TransactionData> wantedEntries = new ArrayList<>();

		for (TransactionData entry : sortedEntries) {
			if (entry.getCollectionID().startsWith("ORTT") || entry.getCollectionID().startsWith("IRTT"))
				wantedEntries.add(entry);
		}

		return wantedEntries;
	}
	

	public List<JSONObject> getDetails(List<TransactionData> sorted) {

		List<JSONObject> allResponse = new ArrayList<>(); //list will contain individual responses of each cid
		List<String> collectionIds = new ArrayList<>(); // list will store unique cid
		
		//loop for storing unique cid in the list
		for (TransactionData entry : sorted) {
			if (!collectionIds.contains(entry.getCollectionID())) {
				collectionIds.add(entry.getCollectionID());
			}
		}
		
		//loop through the cid list, and creating individual response for all of them
		for (String collectionId : collectionIds) {

			String setID = "";
			JSONObject data = new JSONObject();
			JSONArray transactionDetails = new JSONArray();

			for (TransactionData entry : sorted) {
				if (collectionId.equals(entry.getCollectionID())) {
					if (!setID.equals(collectionId)) {
						setID = collectionId;
						System.out.println("CID: "+setID);
						data.put("inOutInd", entry.getIn_out_ind());
						data.put("custEmail", entry.getCustEmail());
						data.put("brId", entry.getBrID());
						data.put("brName", entry.getBrName());
						data.put("brAddress1", entry.getBrAddr1());
						data.put("brAddress2", entry.getBrAddr2());
						data.put("brAddress3", entry.getBrAddr3());
						data.put("brCity", entry.getBrCity());
						data.put("brState", entry.getBrState());
						data.put("brPinCode", entry.getBrPinCode());
						data.put("collectionId", entry.getCollectionID());
						data.put("lodgeDate", entry.getLodgDate());
						data.put("partyName", entry.getPartyName());
						data.put("partyAddress1", entry.getPartyAddr1());
						data.put("partyAddress2", entry.getPartyAddr2());
						data.put("partyAddress3", entry.getPartyAddr3());
						data.put("partyCity", entry.getPartyCity());
						data.put("partyState", entry.getPartyState());
						data.put("partyCountry", entry.getPartyCountry());
						data.put("partyPinCode", entry.getPartyPinCode());
						data.put("otherPartyName", entry.getOtherPartyName());
						data.put("otherPartyAddress1", entry.getOtherPartyAddr1());
						data.put("otherPartyAddress2", entry.getOtherPartyAddr2());
						data.put("otherPartyAddress3", entry.getOtherPartyAddr3());
						data.put("otherPartyCity", entry.getOtherPartyCity());
						data.put("otherPartyState", entry.getOtherPartyState());
						data.put("otherPartyCountry", entry.getOtherPartyCountry());
						data.put("otherPartyPinCode", entry.getOtherPartyPinCode());
						data.put("purposeCode", entry.getPurposeCode());
						data.put("remitCurrency", entry.getRemitCrncy());
						data.put("remitAmount", entry.getRemitAmt());
						data.put("rate", entry.getRate());
						data.put("operateAccount", entry.getOperAcct());
						data.put("operateAccountCurrency", entry.getOperAcctCrncy());
					}
					if(entry.getIndicator().equals("CHRG")) {
						JSONObject individualTransactionDetails = new JSONObject();
						individualTransactionDetails.put("indicator", entry.getIndicator());
						individualTransactionDetails.put("remarks", entry.getRemarkCharges());
						individualTransactionDetails.put("currenyCode", entry.getChrgCrncyCode());
						individualTransactionDetails.put("amount", entry.getTtlChrgCollAmt());
						
						transactionDetails.put(individualTransactionDetails);
						
					}
					else {
						JSONObject individualTransactionDetails = new JSONObject();
						individualTransactionDetails.put("indicator", entry.getIndicator());
						individualTransactionDetails.put("currenyCode", entry.getChrgOperCrncy());
						individualTransactionDetails.put("amount", entry.getTranAmt());
						data.put("valueDate", entry.getValueDate());
						data.put("chargesOperateAccount", entry.getChrgOperAcct());
						data.put("chargesOperateCurrency", entry.getChrgOperCrncy());
						data.put("partTranType", entry.getPartTranType());
						data.put("tranAmount", entry.getTranAmt());
						
						transactionDetails.put(individualTransactionDetails);
					}
					
					data.put("transactionDetails", transactionDetails);
					
				}

				
			}
			allResponse.add(data);
			System.out.println("Size: "+allResponse.size());
		}
		
		return allResponse;
	}
	
	

}


