package com.kyzer.remittance.controller;

import java.util.List;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kyzer.remittance.model.TransactionData;
import com.kyzer.remittance.service.TransactionService;

@RestController
public class TransactionController {
	
	@Autowired
	TransactionService service;
	
	@GetMapping("/details")
	public  ResponseEntity<String> getDetails() {
		
		List<TransactionData> sorted = service.sortEntries();
		List<JSONObject> response = service.getDetails(sorted);
		return ResponseEntity.status(HttpStatus.OK).body(response.toString());
		
	}
	
}












